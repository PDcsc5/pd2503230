/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on July 7, 2014, 12:23 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 

{
    float num1,num2;
    cout<<"enter the first number: \n";
    cin>>num1;
    cout<<"enter the second number: \n";
    cin>>num2;
    if (num1>num2)
    {
        cout<<"first number is larger";
    }
    else if (num1==num2)
    {
        cout<<"the two numbers are equal";
    }
    else
        cout<<"fist number is smaller";
    

    return 0;
}

